package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.constants.GlobalConstants;
import softuni.exam.models.dtos.TicketSeedDto;
import softuni.exam.models.dtos.TicketSeedRootDto;
import softuni.exam.models.entities.Passenger;
import softuni.exam.models.entities.Plane;
import softuni.exam.models.entities.Ticket;
import softuni.exam.models.entities.Town;
import softuni.exam.repository.TicketRepository;
import softuni.exam.service.PassengerService;
import softuni.exam.service.PlaneService;
import softuni.exam.service.TicketService;
import softuni.exam.service.TownService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
@Transactional
public class TicketServiceImpl implements TicketService {
    private final TicketRepository ticketRepository;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final TownService townService;
    private final PassengerService passengerService;
    private final PlaneService planeService;

    @Autowired
    public TicketServiceImpl(TicketRepository ticketRepository, XmlParser xmlParser, ValidationUtil validationUtil, ModelMapper modelMapper, TownService townService, PassengerService passengerService, PlaneService planeService) {
        this.ticketRepository = ticketRepository;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.townService = townService;
        this.passengerService = passengerService;
        this.planeService = planeService;
    }

    @Override
    public boolean areImported() {
        return this.ticketRepository.count() > 0;
    }

    @Override
    public String readTicketsFileContent() throws IOException {
        return Files.readString(Path.of(GlobalConstants.TICKETS_FILE_PATH));
    }

    @Override
    public String importTickets() throws JAXBException, FileNotFoundException {
        StringBuilder builder = new StringBuilder();

        TicketSeedRootDto ticketSeedRootDtos =
                this.xmlParser.parseXml(
                        TicketSeedRootDto.class,
                        GlobalConstants.TICKETS_FILE_PATH);

        for (TicketSeedDto ticketSeedDto : ticketSeedRootDtos.getTickets()) {
            if (this.validationUtil.isValid(ticketSeedDto)) {
                if (this.ticketRepository.findBySerialNumber(ticketSeedDto.getSerialNumber()) == null) {

                    Ticket ticket = this.modelMapper.map(ticketSeedDto, Ticket.class);


                    LocalDateTime takeOff = LocalDateTime.parse(
                            ticketSeedDto.getTakeoff(),
                            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                    );


                    Town fromTown = this.townService.findByName(ticketSeedDto.getFromTown().getName());
                    Town toTown = this.townService.findByName(ticketSeedDto.getToTown().getName());
                    Passenger passenger = this.passengerService.findByEmail(ticketSeedDto.getPassenger().getEmail());
                    Plane plane = this.planeService.findByRegisterNumber(ticketSeedDto.getPlane().getRegisterNumber());

                    if (fromTown != null
                            &&
                            toTown != null
                            &&
                            passenger != null
                            &&
                            plane != null) {

                        ticket.setTakeoff(takeOff);
                        ticket.setFromTown(fromTown);
                        ticket.setToTown(toTown);
                        ticket.setPassenger(passenger);
                        ticket.setPlane(plane);

                        builder.append(String.format(
                                "Successfully imported Ticket %s - %s",
                                ticket.getFromTown().getName(),
                                ticket.getToTown().getName()
                        ));

                       this.ticketRepository.saveAndFlush(ticket);

                    } else {
                        builder.append("Invalid Ticket");
                    }

                } else {
                    builder.append("Invalid Ticket");
                }
            } else {
                builder.append("Invalid Ticket");
            }
            builder.append(System.lineSeparator());
        }

        return builder.toString();
    }
}
