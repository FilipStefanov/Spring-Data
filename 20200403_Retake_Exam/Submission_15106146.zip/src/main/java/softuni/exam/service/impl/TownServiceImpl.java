package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.constants.GlobalConstants;
import softuni.exam.models.dtos.TownSeedDto;
import softuni.exam.models.entities.Town;
import softuni.exam.repository.TownRepository;
import softuni.exam.service.TownService;
import softuni.exam.util.ValidationUtil;

import javax.transaction.Transactional;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
@Transactional
public class TownServiceImpl implements TownService {
    private final TownRepository townRepository;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public TownServiceImpl(TownRepository townRepository, Gson gson, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.townRepository = townRepository;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public Town findByName(String name) {
        return this.townRepository.findByName(name);
    }

    @Override
    public boolean areImported() {
        return this.townRepository.count() > 0;
    }

    @Override
    public String readTownsFileContent() throws IOException {
        return Files.readString(Path.of(GlobalConstants.TOWNS_FILE_PATH));
    }

    @Override
    public String importTowns() throws FileNotFoundException {
        StringBuilder builder = new StringBuilder();

        TownSeedDto[] townSeedDtos =
                this.gson.fromJson(
                        new FileReader(GlobalConstants.TOWNS_FILE_PATH),
                        TownSeedDto[].class);

        for (TownSeedDto townSeedDto : townSeedDtos) {
            if (this.validationUtil.isValid(townSeedDto)) {
                if (this.townRepository.findByName(townSeedDto.getName()) == null) {

                    Town town = this.modelMapper.map(townSeedDto, Town.class);
                    builder.append(String.format(
                            "Successfully imported Town %s - %d",
                            town.getName(),
                            town.getPopulation()
                    ));

                    this.townRepository.saveAndFlush(town);

                } else {
                    builder.append("Invalid Town");
                }
            } else {
                builder.append("Invalid Town");
            }
            builder.append(System.lineSeparator());
        }


        return builder.toString();
    }
}
