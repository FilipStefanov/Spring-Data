package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.constants.GlobalConstants;
import softuni.exam.models.dtos.PlaneSeedRootDto;
import softuni.exam.models.entities.Plane;
import softuni.exam.repository.PlaneRepository;
import softuni.exam.service.PlaneService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
@Transactional
public class PlaneServiceImpl implements PlaneService {
    private final PlaneRepository planeRepository;
    private final XmlParser xmlParser;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;

    @Autowired
    public PlaneServiceImpl(PlaneRepository planeRepository, XmlParser xmlParser, ValidationUtil validationUtil, ModelMapper modelMapper) {
        this.planeRepository = planeRepository;
        this.xmlParser = xmlParser;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
    }

    @Override
    public Plane findByRegisterNumber(String registerNumber) {
        return this.planeRepository.findByRegisterNumber(registerNumber);
    }

    @Override
    public boolean areImported() {
        return this.planeRepository.count() > 0;
    }

    @Override
    public String readPlanesFileContent() throws IOException {
        return Files.readString(Path.of(GlobalConstants.PLANES_FILE_PATH));
    }

    @Override
    public String importPlanes() throws JAXBException, FileNotFoundException {
        StringBuilder builder = new StringBuilder();

        PlaneSeedRootDto planeSeedRootDtos =
                this.xmlParser.parseXml(
                        PlaneSeedRootDto.class,
                        GlobalConstants.PLANES_FILE_PATH);

        planeSeedRootDtos.getPlanes().forEach(planeSeedDto -> {
            if (this.validationUtil.isValid(planeSeedDto)) {
                if (this.planeRepository.findByRegisterNumber(planeSeedDto.getRegisterNumber()) == null) {
                    Plane plane = this.modelMapper.map(planeSeedDto, Plane.class);
                    builder.append(String.format(
                            "Successfully imported Plane %s",
                            plane.getRegisterNumber()
                    ));
                    this.planeRepository.saveAndFlush(plane);
                } else {
                    builder.append("Invalid Plane");
                }
            } else {
                builder.append("Invalid Plane");
            }
            builder.append(System.lineSeparator());

        });


        return builder.toString();
    }
}
